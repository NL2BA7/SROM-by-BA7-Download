Sound Realism Overhaul Mod - Wooden Coaster Edition
Version 1.1
Created by BA7

Realistic wooden coaster audio layered on top of NL2's stock sound:
distance-based roar, chain lift, brake release, screams, drop screams,
G-force rumble and a separate on-ride mix.


INSTALL
1. Copy the folder into you park folder.
2. In editor, open scenery tab and grab the NL2sco object.
3. Place the orange cube within 400 m of the wooden coaster's track (one per coaster).

Lift sections are found automatically when they are named like "Lift 1", "Lift 2",
"Lift Hill 2", "Chain Lift 2" or "Section 7" etc.

Keep the folder together - the scripts and the "sounds" folder must stay next to
the .nl2sco. 

Please credit BA7 if you share it. 

Enjoy!!
